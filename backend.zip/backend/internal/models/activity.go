package models

import (
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

type ActivityType string

const (
	ActivityCreated    ActivityType = "created"
	ActivityUpdated    ActivityType = "updated"
	ActivityContacted  ActivityType = "contacted"
	ActivityNote       ActivityType = "note"
	ActivityStatusChange ActivityType = "status_change"
	ActivityAssigned   ActivityType = "assigned"
)

type Activity struct {
	ID         primitive.ObjectID `bson:"_id,omitempty" json:"id"`
	LeadID     primitive.ObjectID `bson:"lead_id" json:"lead_id"`
	BusinessID primitive.ObjectID `bson:"business_id" json:"business_id"`
	UserID     primitive.ObjectID `bson:"user_id" json:"user_id"`
	UserName   string             `bson:"user_name" json:"user_name"`
	Type       ActivityType       `bson:"type" json:"type"`
	Message    string             `bson:"message" json:"message"`
	Metadata   map[string]string  `bson:"metadata,omitempty" json:"metadata,omitempty"`
	CreatedAt  time.Time          `bson:"created_at" json:"created_at"`
}
