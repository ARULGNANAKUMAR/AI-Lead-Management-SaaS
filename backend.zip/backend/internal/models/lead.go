package models

import (
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

type LeadStatus string
type LeadSource string

const (
	StatusNew        LeadStatus = "new"
	StatusContacted  LeadStatus = "contacted"
	StatusQualified  LeadStatus = "qualified"
	StatusProposal   LeadStatus = "proposal"
	StatusWon        LeadStatus = "won"
	StatusLost       LeadStatus = "lost"
)

const (
	SourceWebsite  LeadSource = "website"
	SourceWidget   LeadSource = "widget"
	SourceManual   LeadSource = "manual"
	SourceImport   LeadSource = "import"
	SourceReferral LeadSource = "referral"
)

type Lead struct {
	ID          primitive.ObjectID `bson:"_id,omitempty" json:"id"`
	BusinessID  primitive.ObjectID `bson:"business_id" json:"business_id"`
	AssignedTo  primitive.ObjectID `bson:"assigned_to,omitempty" json:"assigned_to"`

	// Contact info
	Name        string `bson:"name" json:"name"`
	Email       string `bson:"email" json:"email"`
	Phone       string `bson:"phone" json:"phone"`
	Company     string `bson:"company" json:"company"`
	JobTitle    string `bson:"job_title" json:"job_title"`

	// Lead details
	Status      LeadStatus `bson:"status" json:"status"`
	Source      LeadSource `bson:"source" json:"source"`
	Value       float64    `bson:"value" json:"value"`
	Notes       string     `bson:"notes" json:"notes"`
	Tags        []string   `bson:"tags" json:"tags"`

	// Meta
	Message     string    `bson:"message" json:"message"` // from widget form
	IPAddress   string    `bson:"ip_address" json:"ip_address"`
	UserAgent   string    `bson:"user_agent" json:"user_agent"`
	ReferrerURL string    `bson:"referrer_url" json:"referrer_url"`

	CreatedAt   time.Time `bson:"created_at" json:"created_at"`
	UpdatedAt   time.Time `bson:"updated_at" json:"updated_at"`
	ContactedAt *time.Time `bson:"contacted_at,omitempty" json:"contacted_at"`
}

type LeadFilter struct {
	Status   string
	Source   string
	AssignedTo string
	Search   string
	Page     int
	Limit    int
	SortBy   string
	SortDir  int // 1 asc, -1 desc
}
