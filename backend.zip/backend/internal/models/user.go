package models

import (
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

type Role string

const (
	RoleUser  Role = "user"
	RoleAdmin Role = "admin"
)

type User struct {
	ID         primitive.ObjectID `bson:"_id,omitempty" json:"id"`
	GoogleID   string             `bson:"google_id" json:"google_id"`
	Email      string             `bson:"email" json:"email"`
	Name       string             `bson:"name" json:"name"`
	Avatar     string             `bson:"avatar" json:"avatar"`
	Role       Role               `bson:"role" json:"role"`
	BusinessID primitive.ObjectID `bson:"business_id,omitempty" json:"business_id"`
	CreatedAt  time.Time          `bson:"created_at" json:"created_at"`
	UpdatedAt  time.Time          `bson:"updated_at" json:"updated_at"`
	LastLogin  time.Time          `bson:"last_login" json:"last_login"`
	IsActive   bool               `bson:"is_active" json:"is_active"`
}

type Session struct {
	ID        primitive.ObjectID `bson:"_id,omitempty" json:"id"`
	UserID    primitive.ObjectID `bson:"user_id" json:"user_id"`
	Token     string             `bson:"token" json:"token"`
	ExpiresAt time.Time          `bson:"expires_at" json:"expires_at"`
	CreatedAt time.Time          `bson:"created_at" json:"created_at"`
	UserAgent string             `bson:"user_agent" json:"user_agent"`
	IP        string             `bson:"ip" json:"ip"`
}
