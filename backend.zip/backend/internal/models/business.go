package models

import (
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

type Business struct {
	ID          primitive.ObjectID   `bson:"_id,omitempty" json:"id"`
	Name        string               `bson:"name" json:"name"`
	Domain      string               `bson:"domain" json:"domain"`
	OwnerID     primitive.ObjectID   `bson:"owner_id" json:"owner_id"`
	MemberIDs   []primitive.ObjectID `bson:"member_ids" json:"member_ids"`
	Plan        string               `bson:"plan" json:"plan"` // free, pro, enterprise
	LeadLimit   int                  `bson:"lead_limit" json:"lead_limit"`
	LeadCount   int                  `bson:"lead_count" json:"lead_count"`
	WidgetKey   string               `bson:"widget_key" json:"widget_key"`
	CreatedAt   time.Time            `bson:"created_at" json:"created_at"`
	UpdatedAt   time.Time            `bson:"updated_at" json:"updated_at"`
	IsActive    bool                 `bson:"is_active" json:"is_active"`
	Settings    BusinessSettings     `bson:"settings" json:"settings"`
}

type BusinessSettings struct {
	NotifyEmail     bool     `bson:"notify_email" json:"notify_email"`
	NotifyEmails    []string `bson:"notify_emails" json:"notify_emails"`
	DefaultAssignee string   `bson:"default_assignee" json:"default_assignee"`
	LeadStatuses    []string `bson:"lead_statuses" json:"lead_statuses"`
	LeadSources     []string `bson:"lead_sources" json:"lead_sources"`
}
