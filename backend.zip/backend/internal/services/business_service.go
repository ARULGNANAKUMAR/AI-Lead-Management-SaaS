package services

import (
	"context"
	"lead-management/internal/database"
	"lead-management/internal/models"
	"time"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
)

func GetBusiness(id primitive.ObjectID) (*models.Business, error) {
	ctx := context.Background()
	var biz models.Business
	err := database.Collection("businesses").FindOne(ctx, bson.M{"_id": id}).Decode(&biz)
	return &biz, err
}

func UpdateBusiness(id primitive.ObjectID, update bson.M) error {
	ctx := context.Background()
	update["updated_at"] = time.Now()
	_, err := database.Collection("businesses").UpdateOne(ctx,
		bson.M{"_id": id},
		bson.M{"$set": update},
	)
	return err
}

func GetAllBusinesses(page, limit int) ([]models.Business, int64, error) {
	ctx := context.Background()
	col := database.Collection("businesses")
	total, _ := col.CountDocuments(ctx, bson.M{})

	skip := int64((page - 1) * limit)
	lim := int64(limit)

	cursor, err := col.Find(ctx, bson.M{}, &struct {
		Skip  *int64
		Limit *int64
		Sort  bson.D
	}{&skip, &lim, bson.D{{Key: "created_at", Value: -1}}})
	if err != nil {
		return nil, 0, err
	}
	defer cursor.Close(ctx)

	var businesses []models.Business
	cursor.All(ctx, &businesses)
	return businesses, total, nil
}
