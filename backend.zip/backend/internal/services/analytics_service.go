package services

import (
	"context"
	"lead-management/internal/database"
	"time"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
)

type DashboardStats struct {
	TotalLeads     int64            `json:"total_leads"`
	NewLeads       int64            `json:"new_leads"`       // last 30 days
	WonLeads       int64            `json:"won_leads"`
	ConversionRate float64          `json:"conversion_rate"`
	ByStatus       map[string]int64 `json:"by_status"`
	BySource       map[string]int64 `json:"by_source"`
	RecentLeads    int64            `json:"recent_leads"`   // last 7 days
	TotalValue     float64          `json:"total_value"`
}

func GetDashboardStats(businessID primitive.ObjectID) (*DashboardStats, error) {
	ctx := context.Background()
	col := database.Collection("leads")
	base := bson.M{"business_id": businessID}

	stats := &DashboardStats{
		ByStatus: make(map[string]int64),
		BySource: make(map[string]int64),
	}

	stats.TotalLeads, _ = col.CountDocuments(ctx, base)

	thirtyDaysAgo := time.Now().AddDate(0, 0, -30)
	sevenDaysAgo := time.Now().AddDate(0, 0, -7)

	stats.NewLeads, _ = col.CountDocuments(ctx, bson.M{
		"business_id": businessID,
		"created_at":  bson.M{"$gte": thirtyDaysAgo},
	})
	stats.RecentLeads, _ = col.CountDocuments(ctx, bson.M{
		"business_id": businessID,
		"created_at":  bson.M{"$gte": sevenDaysAgo},
	})
	stats.WonLeads, _ = col.CountDocuments(ctx, bson.M{
		"business_id": businessID,
		"status":      "won",
	})

	if stats.TotalLeads > 0 {
		stats.ConversionRate = float64(stats.WonLeads) / float64(stats.TotalLeads) * 100
	}

	// Group by status
	statuses := []string{"new", "contacted", "qualified", "proposal", "won", "lost"}
	for _, s := range statuses {
		count, _ := col.CountDocuments(ctx, bson.M{"business_id": businessID, "status": s})
		stats.ByStatus[s] = count
	}

	// Group by source
	sources := []string{"website", "widget", "manual", "referral", "import"}
	for _, s := range sources {
		count, _ := col.CountDocuments(ctx, bson.M{"business_id": businessID, "source": s})
		stats.BySource[s] = count
	}

	// Total pipeline value
	pipeline := bson.A{
		bson.M{"$match": bson.M{"business_id": businessID, "value": bson.M{"$gt": 0}}},
		bson.M{"$group": bson.M{"_id": nil, "total": bson.M{"$sum": "$value"}}},
	}
	cursor, err := col.Aggregate(ctx, pipeline)
	if err == nil {
		defer cursor.Close(ctx)
		if cursor.Next(ctx) {
			var result struct {
				Total float64 `bson:"total"`
			}
			cursor.Decode(&result)
			stats.TotalValue = result.Total
		}
	}

	return stats, nil
}

type MonthlyData struct {
	Month string `json:"month"`
	Count int    `json:"count"`
}

func GetMonthlyLeads(businessID primitive.ObjectID) ([]MonthlyData, error) {
	ctx := context.Background()
	sixMonthsAgo := time.Now().AddDate(0, -6, 0)

	pipeline := bson.A{
		bson.M{"$match": bson.M{
			"business_id": businessID,
			"created_at":  bson.M{"$gte": sixMonthsAgo},
		}},
		bson.M{"$group": bson.M{
			"_id": bson.M{
				"year":  bson.M{"$year": "$created_at"},
				"month": bson.M{"$month": "$created_at"},
			},
			"count": bson.M{"$sum": 1},
		}},
		bson.M{"$sort": bson.D{{Key: "_id.year", Value: 1}, {Key: "_id.month", Value: 1}}},
	}

	cursor, err := database.Collection("leads").Aggregate(ctx, pipeline)
	if err != nil {
		return nil, err
	}
	defer cursor.Close(ctx)

	months := []string{"Jan", "Feb", "Mar", "Apr", "May", "Jun",
		"Jul", "Aug", "Sep", "Oct", "Nov", "Dec"}

	var results []MonthlyData
	for cursor.Next(ctx) {
		var row struct {
			ID    struct{ Year, Month int } `bson:"_id"`
			Count int                       `bson:"count"`
		}
		if cursor.Decode(&row) == nil {
			results = append(results, MonthlyData{
				Month: months[row.ID.Month-1],
				Count: row.Count,
			})
		}
	}
	return results, nil
}
