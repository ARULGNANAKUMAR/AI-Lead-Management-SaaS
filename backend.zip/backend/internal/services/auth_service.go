package services

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"lead-management/internal/config"
	"lead-management/internal/database"
	"lead-management/internal/models"
	"net/http"
	"time"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"golang.org/x/oauth2"
	"golang.org/x/oauth2/google"
)

var googleOAuthConfig *oauth2.Config

func InitOAuth() {
	googleOAuthConfig = &oauth2.Config{
		ClientID:     config.App.GoogleClientID,
		ClientSecret: config.App.GoogleClientSecret,
		RedirectURL:  config.App.FrontendURL + "/api/auth/google/callback",
		Scopes:       []string{"openid", "email", "profile"},
		Endpoint:     google.Endpoint,
	}
}

func GetGoogleAuthURL(state string) string {
	return googleOAuthConfig.AuthCodeURL(state, oauth2.AccessTypeOffline)
}

type GoogleUserInfo struct {
	ID      string `json:"id"`
	Email   string `json:"email"`
	Name    string `json:"name"`
	Picture string `json:"picture"`
}

func ExchangeGoogleCode(code string) (*GoogleUserInfo, error) {
	ctx := context.Background()
	token, err := googleOAuthConfig.Exchange(ctx, code)
	if err != nil {
		return nil, fmt.Errorf("code exchange failed: %w", err)
	}

	client := googleOAuthConfig.Client(ctx, token)
	resp, err := client.Get("https://www.googleapis.com/oauth2/v2/userinfo")
	if err != nil {
		return nil, fmt.Errorf("userinfo fetch failed: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("userinfo returned %d", resp.StatusCode)
	}

	body, _ := io.ReadAll(resp.Body)
	var info GoogleUserInfo
	if err := json.Unmarshal(body, &info); err != nil {
		return nil, err
	}
	return &info, nil
}

func FindOrCreateUser(info *GoogleUserInfo, userAgent, ip string) (*models.User, string, error) {
	ctx := context.Background()
	col := database.Collection("users")

	var user models.User
	err := col.FindOne(ctx, bson.M{"email": info.Email}).Decode(&user)

	if err == mongo.ErrNoDocuments {
		// New user
		role := models.RoleUser
		if info.Email == config.App.AdminEmail {
			role = models.RoleAdmin
		}

		user = models.User{
			ID:        primitive.NewObjectID(),
			GoogleID:  info.ID,
			Email:     info.Email,
			Name:      info.Name,
			Avatar:    info.Picture,
			Role:      role,
			IsActive:  true,
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
			LastLogin: time.Now(),
		}

		if _, err := col.InsertOne(ctx, user); err != nil {
			return nil, "", err
		}

		// Create default business for new user
		biz := &models.Business{
			ID:        primitive.NewObjectID(),
			Name:      info.Name + "'s Business",
			OwnerID:   user.ID,
			MemberIDs: []primitive.ObjectID{user.ID},
			Plan:      "free",
			LeadLimit: 100,
			LeadCount: 0,
			WidgetKey: generateKey(),
			IsActive:  true,
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
			Settings: models.BusinessSettings{
				NotifyEmail:  true,
				LeadStatuses: []string{"new", "contacted", "qualified", "proposal", "won", "lost"},
				LeadSources:  []string{"website", "widget", "manual", "referral"},
			},
		}
		database.Collection("businesses").InsertOne(ctx, biz)

		// Link business to user
		col.UpdateOne(ctx, bson.M{"_id": user.ID}, bson.M{
			"$set": bson.M{"business_id": biz.ID},
		})
		user.BusinessID = biz.ID

	} else if err != nil {
		return nil, "", err
	} else {
		// Update last login + ensure admin role
		update := bson.M{
			"last_login":  time.Now(),
			"updated_at":  time.Now(),
			"google_id":   info.ID,
			"avatar":      info.Picture,
		}
		if user.Email == config.App.AdminEmail && user.Role != models.RoleAdmin {
			update["role"] = models.RoleAdmin
		}
		col.UpdateOne(ctx, bson.M{"_id": user.ID}, bson.M{"$set": update})
	}

	sessionToken, err := createSession(user.ID, userAgent, ip)
	if err != nil {
		return nil, "", err
	}

	return &user, sessionToken, nil
}

func createSession(userID primitive.ObjectID, userAgent, ip string) (string, error) {
	token := generateKey()
	session := models.Session{
		ID:        primitive.NewObjectID(),
		UserID:    userID,
		Token:     token,
		ExpiresAt: time.Now().Add(7 * 24 * time.Hour),
		CreatedAt: time.Now(),
		UserAgent: userAgent,
		IP:        ip,
	}

	ctx := context.Background()
	_, err := database.Collection("sessions").InsertOne(ctx, session)
	return token, err
}

func DeleteSession(token string) error {
	ctx := context.Background()
	_, err := database.Collection("sessions").DeleteOne(ctx, bson.M{"token": token})
	return err
}

func CleanExpiredSessions() {
	ctx := context.Background()
	database.Collection("sessions").DeleteMany(ctx, bson.M{
		"expires_at": bson.M{"$lt": time.Now()},
	})
}

func generateKey() string {
	b := make([]byte, 24)
	rand.Read(b)
	return hex.EncodeToString(b)
}

func GetUserByID(id primitive.ObjectID) (*models.User, error) {
	ctx := context.Background()
	var user models.User
	err := database.Collection("users").FindOne(ctx, bson.M{"_id": id}).Decode(&user)
	return &user, err
}

func ListAllUsers(page, limit int) ([]models.User, int64, error) {
	ctx := context.Background()
	col := database.Collection("users")

	total, _ := col.CountDocuments(ctx, bson.M{})
	skip := int64((page - 1) * limit)

	cursor, err := col.Find(ctx, bson.M{}, &options.FindOptions{
		Skip:  &skip,
		Limit: func() *int64 { l := int64(limit); return &l }(),
		Sort:  bson.D{{Key: "created_at", Value: -1}},
	})
	if err != nil {
		return nil, 0, err
	}
	defer cursor.Close(ctx)

	var users []models.User
	cursor.All(ctx, &users)
	return users, total, nil
}
