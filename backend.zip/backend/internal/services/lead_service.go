package services

import (
	"context"
	"lead-management/internal/database"
	"lead-management/internal/models"
	"math"
	"time"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo/options"
)

func CreateLead(lead *models.Lead) error {
	lead.ID = primitive.NewObjectID()
	lead.CreatedAt = time.Now()
	lead.UpdatedAt = time.Now()
	if lead.Status == "" {
		lead.Status = models.StatusNew
	}

	ctx := context.Background()
	_, err := database.Collection("leads").InsertOne(ctx, lead)
	if err != nil {
		return err
	}

	// Increment business lead count
	database.Collection("businesses").UpdateOne(ctx,
		bson.M{"_id": lead.BusinessID},
		bson.M{"$inc": bson.M{"lead_count": 1}},
	)

	// Log activity
	LogActivity(&models.Activity{
		LeadID:     lead.ID,
		BusinessID: lead.BusinessID,
		UserID:     lead.AssignedTo,
		Type:       models.ActivityCreated,
		Message:    "Lead created",
	})

	return nil
}

func GetLeads(businessID primitive.ObjectID, f models.LeadFilter) ([]models.Lead, int64, error) {
	ctx := context.Background()
	col := database.Collection("leads")

	filter := bson.M{"business_id": businessID}

	if f.Status != "" {
		filter["status"] = f.Status
	}
	if f.Source != "" {
		filter["source"] = f.Source
	}
	if f.Search != "" {
		filter["$or"] = bson.A{
			bson.M{"name": bson.M{"$regex": f.Search, "$options": "i"}},
			bson.M{"email": bson.M{"$regex": f.Search, "$options": "i"}},
			bson.M{"company": bson.M{"$regex": f.Search, "$options": "i"}},
		}
	}

	total, _ := col.CountDocuments(ctx, filter)

	if f.Page < 1 {
		f.Page = 1
	}
	if f.Limit < 1 || f.Limit > 100 {
		f.Limit = 25
	}
	skip := int64((f.Page - 1) * f.Limit)
	limit := int64(f.Limit)

	sortField := "created_at"
	sortDir := -1
	if f.SortBy != "" {
		sortField = f.SortBy
	}
	if f.SortDir != 0 {
		sortDir = f.SortDir
	}

	cursor, err := col.Find(ctx, filter, &options.FindOptions{
		Skip:  &skip,
		Limit: &limit,
		Sort:  bson.D{{Key: sortField, Value: sortDir}},
	})
	if err != nil {
		return nil, 0, err
	}
	defer cursor.Close(ctx)

	var leads []models.Lead
	cursor.All(ctx, &leads)
	return leads, total, nil
}

func GetLeadByID(id, businessID primitive.ObjectID) (*models.Lead, error) {
	ctx := context.Background()
	var lead models.Lead
	err := database.Collection("leads").FindOne(ctx, bson.M{
		"_id":         id,
		"business_id": businessID,
	}).Decode(&lead)
	return &lead, err
}

func UpdateLead(id, businessID primitive.ObjectID, update bson.M, user *models.User) error {
	ctx := context.Background()
	update["updated_at"] = time.Now()

	_, err := database.Collection("leads").UpdateOne(ctx,
		bson.M{"_id": id, "business_id": businessID},
		bson.M{"$set": update},
	)
	if err != nil {
		return err
	}

	LogActivity(&models.Activity{
		LeadID:     id,
		BusinessID: businessID,
		UserID:     user.ID,
		UserName:   user.Name,
		Type:       models.ActivityUpdated,
		Message:    "Lead updated",
	})

	return nil
}

func UpdateLeadStatus(id, businessID primitive.ObjectID, status models.LeadStatus, user *models.User) error {
	ctx := context.Background()
	update := bson.M{"status": status, "updated_at": time.Now()}
	if status == models.StatusContacted {
		now := time.Now()
		update["contacted_at"] = now
	}

	_, err := database.Collection("leads").UpdateOne(ctx,
		bson.M{"_id": id, "business_id": businessID},
		bson.M{"$set": update},
	)
	if err != nil {
		return err
	}

	LogActivity(&models.Activity{
		LeadID:     id,
		BusinessID: businessID,
		UserID:     user.ID,
		UserName:   user.Name,
		Type:       models.ActivityStatusChange,
		Message:    "Status changed to " + string(status),
	})

	return nil
}

func DeleteLead(id, businessID primitive.ObjectID) error {
	ctx := context.Background()
	res, err := database.Collection("leads").DeleteOne(ctx, bson.M{
		"_id":         id,
		"business_id": businessID,
	})
	if err != nil {
		return err
	}
	if res.DeletedCount > 0 {
		database.Collection("businesses").UpdateOne(ctx,
			bson.M{"_id": businessID},
			bson.M{"$inc": bson.M{"lead_count": -1}},
		)
	}
	return nil
}

func LogActivity(a *models.Activity) {
	a.ID = primitive.NewObjectID()
	a.CreatedAt = time.Now()
	ctx := context.Background()
	database.Collection("activities").InsertOne(ctx, a)
}

func GetLeadActivities(leadID primitive.ObjectID) ([]models.Activity, error) {
	ctx := context.Background()
	cursor, err := database.Collection("activities").Find(ctx,
		bson.M{"lead_id": leadID},
		&options.FindOptions{Sort: bson.D{{Key: "created_at", Value: -1}}},
	)
	if err != nil {
		return nil, err
	}
	defer cursor.Close(ctx)

	var activities []models.Activity
	cursor.All(ctx, &activities)
	return activities, nil
}

func GetLeadPages(total int64, limit int) int64 {
	if limit == 0 {
		return 0
	}
	return int64(math.Ceil(float64(total) / float64(limit)))
}
