package database

import (
	"context"
	"lead-management/internal/config"
	"log"
	"time"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

var Client *mongo.Client
var DB *mongo.Database

func Connect() {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	clientOpts := options.Client().ApplyURI(config.App.MongoURI)
	client, err := mongo.Connect(ctx, clientOpts)
	if err != nil {
		log.Fatalf("MongoDB connection failed: %v", err)
	}

	if err = client.Ping(ctx, nil); err != nil {
		log.Fatalf("MongoDB ping failed: %v", err)
	}

	Client = client
	DB = client.Database(config.App.DatabaseName)

	log.Printf("Connected to MongoDB: %s", config.App.DatabaseName)
	ensureIndexes()
}

func ensureIndexes() {
	ctx := context.Background()

	// Users: unique email
	DB.Collection("users").Indexes().CreateOne(ctx, mongo.IndexModel{
		Keys:    bson.D{{Key: "email", Value: 1}},
		Options: options.Index().SetUnique(true),
	})

	// Sessions: TTL index on expires_at
	DB.Collection("sessions").Indexes().CreateOne(ctx, mongo.IndexModel{
		Keys:    bson.D{{Key: "expires_at", Value: 1}},
		Options: options.Index().SetExpireAfterSeconds(0),
	})

	// Leads: index on business_id for fast lookup
	DB.Collection("leads").Indexes().CreateOne(ctx, mongo.IndexModel{
		Keys: bson.D{{Key: "business_id", Value: 1}, {Key: "created_at", Value: -1}},
	})

	// Activities: index on lead_id
	DB.Collection("activities").Indexes().CreateOne(ctx, mongo.IndexModel{
		Keys: bson.D{{Key: "lead_id", Value: 1}},
	})

	log.Println("MongoDB indexes ensured")
}

func Disconnect() {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if Client != nil {
		Client.Disconnect(ctx)
		log.Println("MongoDB disconnected")
	}
}

func Collection(name string) *mongo.Collection {
	return DB.Collection(name)
}
