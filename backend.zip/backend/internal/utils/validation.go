package utils

import (
	"regexp"
	"strings"
)

var emailRegex = regexp.MustCompile(`^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$`)

func IsValidEmail(email string) bool {
	return emailRegex.MatchString(strings.TrimSpace(email))
}

func IsValidPhone(phone string) bool {
	if phone == "" {
		return true // optional
	}
	cleaned := regexp.MustCompile(`[\s\-\(\)\+]`).ReplaceAllString(phone, "")
	return len(cleaned) >= 7 && len(cleaned) <= 15
}

func SanitizeString(s string) string {
	return strings.TrimSpace(s)
}

func IsEmpty(s string) bool {
	return strings.TrimSpace(s) == ""
}
