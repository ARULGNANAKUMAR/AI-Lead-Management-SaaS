package utils

import (
	"fmt"
	"log"
	"os"
	"time"
)

var (
	infoLog  = log.New(os.Stdout, "\033[34m[INFO]\033[0m  ", 0)
	warnLog  = log.New(os.Stdout, "\033[33m[WARN]\033[0m  ", 0)
	errorLog = log.New(os.Stderr, "\033[31m[ERROR]\033[0m ", 0)
)

func ts() string {
	return time.Now().Format("2006-01-02 15:04:05")
}

func Info(format string, args ...interface{}) {
	infoLog.Printf(fmt.Sprintf("%s %s", ts(), format), args...)
}

func Warn(format string, args ...interface{}) {
	warnLog.Printf(fmt.Sprintf("%s %s", ts(), format), args...)
}

func Error(format string, args ...interface{}) {
	errorLog.Printf(fmt.Sprintf("%s %s", ts(), format), args...)
}
