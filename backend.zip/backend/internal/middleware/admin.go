package middleware

import (
	"lead-management/internal/models"
	"lead-management/internal/utils"
	"net/http"
)

func Admin(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		user := GetUser(r)
		if user == nil || user.Role != models.RoleAdmin {
			utils.Forbidden(w)
			return
		}
		next.ServeHTTP(w, r)
	})
}
