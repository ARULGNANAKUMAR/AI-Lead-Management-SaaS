package middleware

import (
	"context"
	"lead-management/internal/database"
	"lead-management/internal/models"
	"lead-management/internal/utils"
	"net/http"
	"strings"
	"time"

	"go.mongodb.org/mongo-driver/bson"
)

type contextKey string

const UserContextKey contextKey = "user"

func Auth(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		token := extractToken(r)
		if token == "" {
			utils.Unauthorized(w)
			return
		}

		ctx := context.Background()
		var session models.Session
		err := database.Collection("sessions").FindOne(ctx, bson.M{
			"token":      token,
			"expires_at": bson.M{"$gt": time.Now()},
		}).Decode(&session)
		if err != nil {
			utils.Unauthorized(w)
			return
		}

		var user models.User
		err = database.Collection("users").FindOne(ctx, bson.M{
			"_id":       session.UserID,
			"is_active": true,
		}).Decode(&user)
		if err != nil {
			utils.Unauthorized(w)
			return
		}

		reqCtx := context.WithValue(r.Context(), UserContextKey, &user)
		next.ServeHTTP(w, r.WithContext(reqCtx))
	})
}

func GetUser(r *http.Request) *models.User {
	user, _ := r.Context().Value(UserContextKey).(*models.User)
	return user
}

func extractToken(r *http.Request) string {
	// Check Authorization header
	bearer := r.Header.Get("Authorization")
	if strings.HasPrefix(bearer, "Bearer ") {
		return strings.TrimPrefix(bearer, "Bearer ")
	}

	// Check cookie
	cookie, err := r.Cookie("session_token")
	if err == nil {
		return cookie.Value
	}

	return ""
}
