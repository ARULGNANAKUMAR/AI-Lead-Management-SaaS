package routes

import (
	"lead-management/internal/handlers"
	"lead-management/internal/middleware"
	"net/http"
)

func Setup(mux *http.ServeMux) {
	// Auth
	mux.HandleFunc("GET /api/auth/google", handlers.GoogleLogin)
	mux.HandleFunc("GET /api/auth/google/callback", handlers.GoogleCallback)
	mux.HandleFunc("POST /api/auth/logout", chain(handlers.Logout, middleware.Auth))
	mux.HandleFunc("GET /api/auth/me", chain(handlers.Me, middleware.Auth))

	// User
	mux.HandleFunc("GET /api/user/profile", chain(handlers.GetProfile, middleware.Auth))
	mux.HandleFunc("PATCH /api/user/profile", chain(handlers.UpdateProfile, middleware.Auth))

	// Business
	mux.HandleFunc("GET /api/business", chain(handlers.GetMyBusiness, middleware.Auth))
	mux.HandleFunc("PATCH /api/business", chain(handlers.UpdateMyBusiness, middleware.Auth))

	// Dashboard
	mux.HandleFunc("GET /api/dashboard/stats", chain(handlers.DashboardStats, middleware.Auth))

	// Leads
	mux.HandleFunc("GET /api/leads", chain(handlers.ListLeads, middleware.Auth))
	mux.HandleFunc("POST /api/leads", chain(handlers.CreateLead, middleware.Auth))
	mux.HandleFunc("GET /api/leads/{id}", chain(handlers.GetLead, middleware.Auth))
	mux.HandleFunc("PUT /api/leads/{id}", chain(handlers.UpdateLead, middleware.Auth))
	mux.HandleFunc("PATCH /api/leads/{id}/status", chain(handlers.UpdateLeadStatus, middleware.Auth))
	mux.HandleFunc("DELETE /api/leads/{id}", chain(handlers.DeleteLead, middleware.Auth))

	// Widget (public)
	mux.HandleFunc("POST /api/widget/submit", handlers.WidgetSubmit)

	// Admin
	mux.HandleFunc("GET /api/admin/users", chain(handlers.AdminListUsers, middleware.Auth, middleware.Admin))
	mux.HandleFunc("GET /api/admin/stats", chain(handlers.AdminStats, middleware.Auth, middleware.Admin))

	// Health check
	mux.HandleFunc("GET /api/health", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(`{"status":"ok"}`))
	})
}

// chain applies middlewares right-to-left
func chain(h http.HandlerFunc, middlewares ...func(http.Handler) http.Handler) http.HandlerFunc {
	handler := http.Handler(h)
	for i := len(middlewares) - 1; i >= 0; i-- {
		handler = middlewares[i](handler)
	}
	return handler.ServeHTTP
}
