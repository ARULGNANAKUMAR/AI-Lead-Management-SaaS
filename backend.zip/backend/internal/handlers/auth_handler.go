package handlers

import (
	"crypto/rand"
	"encoding/hex"
	"lead-management/internal/config"
	"lead-management/internal/middleware"
	"lead-management/internal/services"
	"lead-management/internal/utils"
	"net/http"
	"time"
)

func GoogleLogin(w http.ResponseWriter, r *http.Request) {
	state := generateState()
	http.SetCookie(w, &http.Cookie{
		Name:     "oauth_state",
		Value:    state,
		Path:     "/",
		MaxAge:   300,
		HttpOnly: true,
		Secure:   !config.IsDev(),
		SameSite: http.SameSiteLaxMode,
	})
	url := services.GetGoogleAuthURL(state)
	http.Redirect(w, r, url, http.StatusTemporaryRedirect)
}

func GoogleCallback(w http.ResponseWriter, r *http.Request) {
	// Validate state
	stateCookie, err := r.Cookie("oauth_state")
	if err != nil || stateCookie.Value != r.URL.Query().Get("state") {
		http.Redirect(w, r, config.App.FrontendURL+"/login?error=invalid_state", http.StatusTemporaryRedirect)
		return
	}

	code := r.URL.Query().Get("code")
	if code == "" {
		http.Redirect(w, r, config.App.FrontendURL+"/login?error=no_code", http.StatusTemporaryRedirect)
		return
	}

	googleUser, err := services.ExchangeGoogleCode(code)
	if err != nil {
		utils.Error(w, http.StatusBadRequest, "OAuth exchange failed")
		return
	}

	user, sessionToken, err := services.FindOrCreateUser(googleUser,
		r.Header.Get("User-Agent"), r.RemoteAddr)
	if err != nil {
		utils.InternalError(w)
		return
	}

	http.SetCookie(w, &http.Cookie{
		Name:     "session_token",
		Value:    sessionToken,
		Path:     "/",
		MaxAge:   7 * 24 * 3600,
		HttpOnly: true,
		Secure:   !config.IsDev(),
		SameSite: http.SameSiteStrictMode,
	})

	// Clear oauth state cookie
	http.SetCookie(w, &http.Cookie{
		Name:    "oauth_state",
		Value:   "",
		Path:    "/",
		Expires: time.Unix(0, 0),
	})

	redirect := config.App.FrontendURL + "/dashboard"
	if user.Role == "admin" {
		redirect = config.App.FrontendURL + "/dashboard"
	}
	http.Redirect(w, r, redirect, http.StatusTemporaryRedirect)
}

func Logout(w http.ResponseWriter, r *http.Request) {
	cookie, err := r.Cookie("session_token")
	if err == nil {
		services.DeleteSession(cookie.Value)
	}

	http.SetCookie(w, &http.Cookie{
		Name:    "session_token",
		Value:   "",
		Path:    "/",
		Expires: time.Unix(0, 0),
		MaxAge:  -1,
	})

	utils.Success(w, map[string]string{"message": "Logged out"})
}

func Me(w http.ResponseWriter, r *http.Request) {
	user := middleware.GetUser(r)
	utils.Success(w, user)
}

func generateState() string {
	b := make([]byte, 16)
	rand.Read(b)
	return hex.EncodeToString(b)
}
