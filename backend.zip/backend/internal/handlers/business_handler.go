package handlers

import (
	"encoding/json"
	"lead-management/internal/middleware"
	"lead-management/internal/services"
	"lead-management/internal/utils"
	"net/http"

	"go.mongodb.org/mongo-driver/bson"
)

func GetMyBusiness(w http.ResponseWriter, r *http.Request) {
	user := middleware.GetUser(r)
	biz, err := services.GetBusiness(user.BusinessID)
	if err != nil {
		utils.NotFound(w, "Business not found")
		return
	}
	utils.Success(w, biz)
}

func UpdateMyBusiness(w http.ResponseWriter, r *http.Request) {
	user := middleware.GetUser(r)

	var body map[string]interface{}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		utils.BadRequest(w, "Invalid JSON")
		return
	}

	allowed := []string{"name", "domain", "settings"}
	update := bson.M{}
	for _, field := range allowed {
		if v, ok := body[field]; ok {
			update[field] = v
		}
	}

	if err := services.UpdateBusiness(user.BusinessID, update); err != nil {
		utils.InternalError(w)
		return
	}

	biz, _ := services.GetBusiness(user.BusinessID)
	utils.Success(w, biz)
}
