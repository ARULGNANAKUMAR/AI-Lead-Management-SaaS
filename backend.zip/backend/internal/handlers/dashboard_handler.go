package handlers

import (
	"lead-management/internal/middleware"
	"lead-management/internal/services"
	"lead-management/internal/utils"
	"net/http"
)

func DashboardStats(w http.ResponseWriter, r *http.Request) {
	user := middleware.GetUser(r)

	stats, err := services.GetDashboardStats(user.BusinessID)
	if err != nil {
		utils.InternalError(w)
		return
	}

	monthly, _ := services.GetMonthlyLeads(user.BusinessID)

	utils.Success(w, map[string]interface{}{
		"stats":   stats,
		"monthly": monthly,
	})
}
