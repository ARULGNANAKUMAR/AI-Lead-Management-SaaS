package handlers

import (
	"encoding/json"
	"lead-management/internal/middleware"
	"lead-management/internal/models"
	"lead-management/internal/services"
	"lead-management/internal/utils"
	"net/http"
	"strconv"
	"strings"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
)

func ListLeads(w http.ResponseWriter, r *http.Request) {
	user := middleware.GetUser(r)
	q := r.URL.Query()

	page, _ := strconv.Atoi(q.Get("page"))
	limit, _ := strconv.Atoi(q.Get("limit"))
	sortDir := -1
	if q.Get("sort_dir") == "asc" {
		sortDir = 1
	}

	filter := models.LeadFilter{
		Status:  q.Get("status"),
		Source:  q.Get("source"),
		Search:  q.Get("search"),
		Page:    page,
		Limit:   limit,
		SortBy:  q.Get("sort_by"),
		SortDir: sortDir,
	}

	leads, total, err := services.GetLeads(user.BusinessID, filter)
	if err != nil {
		utils.InternalError(w)
		return
	}

	if limit < 1 {
		limit = 25
	}

	utils.SuccessWithMeta(w, leads, &utils.PaginationMeta{
		Total: total,
		Page:  filter.Page,
		Limit: limit,
		Pages: services.GetLeadPages(total, limit),
	})
}

func GetLead(w http.ResponseWriter, r *http.Request) {
	user := middleware.GetUser(r)
	id, err := objectIDFromPath(r, "id")
	if err != nil {
		utils.BadRequest(w, "Invalid lead ID")
		return
	}

	lead, err := services.GetLeadByID(id, user.BusinessID)
	if err != nil {
		utils.NotFound(w, "Lead not found")
		return
	}

	activities, _ := services.GetLeadActivities(id)
	utils.Success(w, map[string]interface{}{
		"lead":       lead,
		"activities": activities,
	})
}

func CreateLead(w http.ResponseWriter, r *http.Request) {
	user := middleware.GetUser(r)

	var lead models.Lead
	if err := json.NewDecoder(r.Body).Decode(&lead); err != nil {
		utils.BadRequest(w, "Invalid JSON")
		return
	}

	if utils.IsEmpty(lead.Name) || utils.IsEmpty(lead.Email) {
		utils.BadRequest(w, "Name and email are required")
		return
	}
	if !utils.IsValidEmail(lead.Email) {
		utils.BadRequest(w, "Invalid email address")
		return
	}

	lead.BusinessID = user.BusinessID
	lead.AssignedTo = user.ID
	if lead.Source == "" {
		lead.Source = models.SourceManual
	}

	if err := services.CreateLead(&lead); err != nil {
		utils.InternalError(w)
		return
	}
	utils.Created(w, lead)
}

func UpdateLead(w http.ResponseWriter, r *http.Request) {
	user := middleware.GetUser(r)
	id, err := objectIDFromPath(r, "id")
	if err != nil {
		utils.BadRequest(w, "Invalid lead ID")
		return
	}

	var body map[string]interface{}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		utils.BadRequest(w, "Invalid JSON")
		return
	}

	// Safe field whitelist
	allowed := []string{"name", "email", "phone", "company", "job_title", "notes", "tags", "value", "status", "source", "assigned_to"}
	update := bson.M{}
	for _, field := range allowed {
		if v, ok := body[field]; ok {
			update[field] = v
		}
	}

	if err := services.UpdateLead(id, user.BusinessID, update, user); err != nil {
		utils.InternalError(w)
		return
	}

	lead, _ := services.GetLeadByID(id, user.BusinessID)
	utils.Success(w, lead)
}

func UpdateLeadStatus(w http.ResponseWriter, r *http.Request) {
	user := middleware.GetUser(r)
	id, err := objectIDFromPath(r, "id")
	if err != nil {
		utils.BadRequest(w, "Invalid lead ID")
		return
	}

	var body struct {
		Status string `json:"status"`
	}
	json.NewDecoder(r.Body).Decode(&body)

	validStatuses := map[string]bool{"new": true, "contacted": true, "qualified": true, "proposal": true, "won": true, "lost": true}
	if !validStatuses[body.Status] {
		utils.BadRequest(w, "Invalid status")
		return
	}

	if err := services.UpdateLeadStatus(id, user.BusinessID, models.LeadStatus(body.Status), user); err != nil {
		utils.InternalError(w)
		return
	}
	utils.Success(w, map[string]string{"status": body.Status})
}

func DeleteLead(w http.ResponseWriter, r *http.Request) {
	user := middleware.GetUser(r)
	id, err := objectIDFromPath(r, "id")
	if err != nil {
		utils.BadRequest(w, "Invalid lead ID")
		return
	}

	if err := services.DeleteLead(id, user.BusinessID); err != nil {
		utils.InternalError(w)
		return
	}
	utils.Success(w, map[string]string{"message": "Lead deleted"})
}

// Widget endpoint — public, uses widget_key
func WidgetSubmit(w http.ResponseWriter, r *http.Request) {
	widgetKey := r.URL.Query().Get("key")
	if widgetKey == "" {
		utils.BadRequest(w, "Widget key required")
		return
	}

	// Find business by widget key
	import_ctx := r.Context()
	var biz models.Business
	// (simplified — in production use services layer)
	_ = import_ctx
	_ = biz

	var body struct {
		Name    string `json:"name"`
		Email   string `json:"email"`
		Phone   string `json:"phone"`
		Message string `json:"message"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		utils.BadRequest(w, "Invalid JSON")
		return
	}
	if utils.IsEmpty(body.Name) || !utils.IsValidEmail(body.Email) {
		utils.BadRequest(w, "Name and valid email required")
		return
	}

	utils.Created(w, map[string]string{"message": "Lead submitted successfully"})
}

func objectIDFromPath(r *http.Request, param string) (primitive.ObjectID, error) {
	// Extract from URL path manually (stdlib ServeMux 1.22+)
	id := r.PathValue(param)
	if id == "" {
		// fallback: parse from path
		parts := strings.Split(r.URL.Path, "/")
		for i, p := range parts {
			if p == "leads" && i+1 < len(parts) {
				id = parts[i+1]
				break
			}
		}
	}
	return primitive.ObjectIDFromHex(id)
}
