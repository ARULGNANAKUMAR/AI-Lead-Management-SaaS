package handlers

import (
	"encoding/json"
	"lead-management/internal/database"
	"lead-management/internal/middleware"
	"lead-management/internal/utils"
	"net/http"
	"time"

	"go.mongodb.org/mongo-driver/bson"
	"context"
)

func GetProfile(w http.ResponseWriter, r *http.Request) {
	user := middleware.GetUser(r)
	utils.Success(w, user)
}

func UpdateProfile(w http.ResponseWriter, r *http.Request) {
	user := middleware.GetUser(r)

	var body struct {
		Name string `json:"name"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		utils.BadRequest(w, "Invalid JSON")
		return
	}

	if utils.IsEmpty(body.Name) {
		utils.BadRequest(w, "Name is required")
		return
	}

	ctx := context.Background()
	database.Collection("users").UpdateOne(ctx,
		bson.M{"_id": user.ID},
		bson.M{"$set": bson.M{"name": body.Name, "updated_at": time.Now()}},
	)

	user.Name = body.Name
	utils.Success(w, user)
}
