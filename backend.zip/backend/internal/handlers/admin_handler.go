package handlers

import (
	"lead-management/internal/services"
	"lead-management/internal/utils"
	"net/http"
	"strconv"
)

func AdminListUsers(w http.ResponseWriter, r *http.Request) {
	page, _ := strconv.Atoi(r.URL.Query().Get("page"))
	limit, _ := strconv.Atoi(r.URL.Query().Get("limit"))
	if page < 1 { page = 1 }
	if limit < 1 { limit = 20 }

	users, total, err := services.ListAllUsers(page, limit)
	if err != nil {
		utils.InternalError(w)
		return
	}

	utils.SuccessWithMeta(w, users, &utils.PaginationMeta{
		Total: total,
		Page:  page,
		Limit: limit,
		Pages: services.GetLeadPages(total, limit),
	})
}

func AdminStats(w http.ResponseWriter, r *http.Request) {
	// Platform-wide stats for admin
	utils.Success(w, map[string]string{"message": "Admin stats endpoint"})
}
