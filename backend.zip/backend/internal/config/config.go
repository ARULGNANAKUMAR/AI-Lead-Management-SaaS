package config

import (
	"log"
	"os"
	"strings"

	"github.com/joho/godotenv"
)

type Config struct {
	MongoURI        string
	DatabaseName    string
	GoogleClientID  string
	GoogleClientSecret string
	SessionSecret   string
	AdminEmail      string
	Port            string
	FrontendURL     string
	AllowedOrigins  []string
	Environment     string
}

var App *Config

func Load() {
	// Load .env file if exists (dev only)
	if err := godotenv.Load(); err != nil {
		log.Println("No .env file found, reading from environment")
	}

	App = &Config{
		MongoURI:           getEnv("MONGODB_URI", ""),
		DatabaseName:       getEnv("DATABASE_NAME", "lead_management"),
		GoogleClientID:     getEnv("GOOGLE_CLIENT_ID", ""),
		GoogleClientSecret: getEnv("GOOGLE_CLIENT_SECRET", ""),
		SessionSecret:      getEnv("SESSION_SECRET", "changeme-in-production-32chars!!"),
		AdminEmail:         getEnv("ADMIN_EMAIL", "arulgnanakumar@gmail.com"),
		Port:               getEnv("PORT", "8080"),
		FrontendURL:        getEnv("FRONTEND_URL", "http://localhost:3000"),
		AllowedOrigins:     strings.Split(getEnv("ALLOWED_ORIGINS", "http://localhost:3000"), ","),
		Environment:        getEnv("ENVIRONMENT", "development"),
	}

	if App.MongoURI == "" {
		log.Fatal("MONGODB_URI is required")
	}
	if App.GoogleClientID == "" {
		log.Fatal("GOOGLE_CLIENT_ID is required")
	}
}

func getEnv(key, fallback string) string {
	if val := os.Getenv(key); val != "" {
		return val
	}
	return fallback
}

func IsDev() bool {
	return App.Environment == "development"
}
