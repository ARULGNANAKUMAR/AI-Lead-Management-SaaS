package main

import (
	"context"
	"lead-management/internal/config"
	"lead-management/internal/database"
	"lead-management/internal/middleware"
	"lead-management/internal/routes"
	"lead-management/internal/services"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"
)

func main() {
	// Load config
	config.Load()

	// Connect DB
	database.Connect()
	defer database.Disconnect()

	// Init OAuth
	services.InitOAuth()

	// Setup router
	mux := http.NewServeMux()
	routes.Setup(mux)

	// Apply global middleware (order matters: outermost first)
	handler := middleware.Security(
		middleware.CORS(
			middleware.RateLimit(mux),
		),
	)

	srv := &http.Server{
		Addr:         ":" + config.App.Port,
		Handler:      handler,
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 15 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	// Session cleanup goroutine
	go func() {
		ticker := time.NewTicker(1 * time.Hour)
		for range ticker.C {
			services.CleanExpiredSessions()
		}
	}()

	// Graceful shutdown
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)

	go func() {
		log.Printf("Server starting on port %s", config.App.Port)
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("Server error: %v", err)
		}
	}()

	<-quit
	log.Println("Shutting down server...")

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	srv.Shutdown(ctx)

	log.Println("Server stopped")
}
